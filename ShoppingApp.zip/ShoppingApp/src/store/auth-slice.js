import { createSlice } from "@reduxjs/toolkit";
const AuthSlice = createSlice({
    name:'auth',
    initialState:{loggedIn:false},
    reducers:{
        login(state,action)
        {
            state.loggedIn = true;
        },
        logout(state,action)
        {
            state.loggedIn = false;
        }
    }
})

export const myActionsAuth  = AuthSlice.actions; 
export default AuthSlice;

