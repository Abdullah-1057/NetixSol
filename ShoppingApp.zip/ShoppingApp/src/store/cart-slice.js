import { createSlice } from "@reduxjs/toolkit";
const CartSlice = createSlice({
    name:'cart',
    initialState:{
        //total cart data fields
        itemList:[],
        totalQuantity:0,
        showCart:false
    },
    reducers:{
       addToCart(state,action)
       {
        const newItem = action.payload;
        const ExsisteingItem = state.itemList.find((item)=>item.id===newItem.id);
        // this is for a single item incrementtig
        //single item data fields
        if(ExsisteingItem)
        {
            ExsisteingItem.quantity++;
            ExsisteingItem.TotalPrice+=newItem.price;
        }
        else{
            //Total Array//Rememeber: This is only the item List data
            state.itemList.push({
                id: newItem.id,
                price: newItem.price,
                quantity:1,                 
                TotalPrice: newItem.price, //at initialization it will be the same 
                name:newItem.name,//we donot need to store every item indivually rather than that
                // only the total array of items
            })
        }
        state.totalQuantity++;
       },
       RemoveFromCart(state,action)
       {    
            const id = action.payload;
            const ExsistingItem  =   state.itemList.find((item)=>item.id===id);
            if(ExsistingItem.quantity===1)
            {
                state.itemList = state.itemList.filter((item)=>{return item.id!==id})
            }
            else
            {
                ExsistingItem.quantity--;
                ExsistingItem.TotalPrice -= ExsistingItem.price;
            }
            state.totalQuantity--;
       },
       setShowCart(state,action)
       {
        if(state.showCart===true)
        {
            state.showCart = false;
        }
        else
        {
            state.showCart = true;
        }
       } 
    }
})

export const myActionsCart  = CartSlice.actions; 
export default CartSlice;
