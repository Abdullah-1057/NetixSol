import { configureStore } from "@reduxjs/toolkit";
import AuthSlice from "./auth-slice";
import CartSlice from "./cart-slice";
import storage from 'redux-persist/lib/storage';
import { persistStore, persistReducer } from 'redux-persist';
import { combineReducers } from 'redux';
// import autoMergeLevel2 from 'redux-persist/lib/stateReconciler/autoMergeLevel2';
import thunk from 'redux-thunk'

const persistConfig = {
    key: 'root',
    storage: storage,
    // stateReconciler: autoMergeLevel2
   };

const rootReducer = combineReducers({ auth: AuthSlice.reducer, cart: CartSlice.reducer });

const pReducer = persistReducer(persistConfig, rootReducer);

const store = configureStore({reducer:pReducer,
        devTools: process.env.NODE_ENV !== 'production',
        middleware: [thunk]
    });
// export const persistor = persistStore(store);
export default store;

/*
import { configureStore } from "@reduxjs/toolkit";
import AuthSlice from "./auth-slice";
import CartSlice from "./cart-slice";

const store = configureStore({
    reducer:{ 
        auth:AuthSlice.reducer,
        cart:CartSlice.reducer
    }
})

export default store;

 */


/*
import { configureStore } from "@reduxjs/toolkit";
import AuthSlice from "./auth-slice";
import CartSlice from "./cart-slice";
import storage from 'redux-persist/lib/storage';
import { persistStore, persistReducer } from 'redux-persist';
import { combineReducers } from 'redux';
import autoMergeLevel2 from 'redux-persist/lib/stateReconciler/autoMergeLevel2';

const persistConfig = {
    key: 'root',
    storage: storage,
    stateReconciler: autoMergeLevel2
   };
const rootReducer = combineReducers({
    auth:AuthSlice,
    cart:CartSlice
  });
const pReducer = persistReducer(persistConfig, rootReducer);

const store = configureStore(pReducer);
export const persistor = persistStore(store);
export default store;
 */