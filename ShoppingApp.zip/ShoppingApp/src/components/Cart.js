import React from "react";
import { useDispatch } from "react-redux";
import { useSelector } from "react-redux";
import { myActionsCart } from "../store/cart-slice";
import "./Cart.css";
const Cart = () => {
  const dispatch = useDispatch();
  const ShowCartHandler = () =>{
    dispatch(myActionsCart.setShowCart());
  }
  const quantity = useSelector((state)=>{return state.cart.totalQuantity});
  return (
    <div className="cartIcon">
      <h3 onClick={ShowCartHandler}>Click to View Cart: {quantity} Items</h3>
    </div>
  );
};

export default Cart;
