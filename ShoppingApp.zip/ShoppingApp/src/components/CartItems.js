import React from "react";
import CartItem from "./CartItem";
import "./Cart.css";
import { useSelector } from "react-redux";
const CartItems = () => {
  const MyCartItems = useSelector((state)=>{return state.cart.itemList});
  return (
    <div className="cart-container">
      <h2>Your Cart</h2>
      <ul>
        {MyCartItems.map(MyCartItems=>(
        <li key = {MyCartItems.id}>
          {" "}
          <CartItem id={MyCartItems.id} price={MyCartItems.price} name={MyCartItems.name} quantity={MyCartItems.quantity} total={MyCartItems.TotalPrice}/>
        </li>
        ))}
      </ul> 
    </div>
  );
};

export default CartItems;
