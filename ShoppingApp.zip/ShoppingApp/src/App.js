import React from "react";
import "./App.css";
import Auth from "./components/Auth";
import Layout from "./components/Layout";
import { useSelector } from "react-redux";
function App() {

  const isLoggedIn = useSelector((state)=>{return state.auth.loggedIn})
  const CartItemsList = useSelector((state)=> state.cart.itemList);
  console.log(CartItemsList);

  return (
    <div className="App">
      {!isLoggedIn && <Auth />}
      {isLoggedIn && <Layout />}
      {/* <Auth />
      <Layout /> */}
    </div>
  );
}

export default App;
