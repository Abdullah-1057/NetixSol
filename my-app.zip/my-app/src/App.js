import logo from "./logo.svg";
import "./App.css";
import MainBody from "./components/MainBody";
import MyCard from "./components/Card";
import Navbar from "./components/Navbar";
import React, { useState } from "react";
import { FaBeer } from "react-icons/fa";
import { BsSun } from "react-icons/bs";
import { BsMoon } from "react-icons/bs";

function App() {
  // let flag = 0;
  const [darkToggle, setDarkToggle] = React.useState(false);
  const [flag, setFlag] = useState(0);
  const [mode, setMode] = useState("Dark Mode");

  const toggleDarkMode = () => {
    setFlag(!flag);
    if(flag==1)
    {
      setMode("Light Mode");
    }
    else
    {
      setMode("Dark Mode");

    }
    setDarkToggle(!darkToggle);
  };

  console.log({ flag });
  return (
    <>
      <div className={` ${darkToggle && "dark"}`}>
        <div className="dark:bg-gray-800 bg-gray-100 dark:text-white">
          <div className="MyNavBar">
            <nav className={`bg-white border-gray-200 rounded `}>
              <div className="max-w-7xl mx-auto dark:bg-gray-600">
                <div className="flex items-center justify-between h-16 sm:max-w-xl md:max-w-5xl sm:py-1 md:py-3 lg:px-0 md:px-6 px-8 lg:py-12 MainBody">
                  <div className="flex-shrink-0">
                    <div className="text-4xl font-bold">
                      Where in the world?
                    </div>
                  </div>

                  <div className="w-auto">
                    <div onClick={toggleDarkMode}>
                      <ul className="flex flex-row">

                        <li className="mt-1"> {flag ? <BsSun /> : <BsMoon />}</li>
                        <li className="hidden md:block pl-4">{mode}</li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </nav>
          </div>
          {/* <MainBody/> */}
          <div className="sm:max-w-xl md:max-w-5xl sm:pt-1 md:pt-5 lg:pt-10 MainBody ">
            <MyCard />
          </div>
        </div>
      </div>
    </>
  );
}

export default App;
