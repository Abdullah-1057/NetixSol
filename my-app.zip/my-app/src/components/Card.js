import { useState } from "react";
import { Fragment } from "react";
import { Menu, Transition } from "@headlessui/react";
import { ChevronDownIcon } from "@heroicons/react/20/solid";
function classNames(...classes) {
  return classes.filter(Boolean).join(" ");
}
export default function MyCard() {
  const countries = require("./data");
  const [filteredList, setFilteredList] = new useState(countries);
  const filterBySearch = (v) => {
    var updatedList = [...countries];
    updatedList = updatedList.filter((item) => {
      return item.name.toLowerCase().indexOf(v.toLowerCase()) !== -1;
    });
    setFilteredList(updatedList);
  };
  const HandleContinent = (v) => {
    var updatedList = [...countries];
    updatedList = updatedList.filter((item) => {
      return item.region.toLowerCase().indexOf(v.toLowerCase()) !== -1;
    });
    setFilteredList(updatedList);
  };
  return (
    <>
      <div className="grid grid-cols-6 gap-4 Main-Body lg:mt-2 md:mt-4 mt-10">
        <div className="md:col-span-2 m-auto  lg:justify-start lg:w-11/12 w-9/12 col-span-6">
          <label
            for="default-search"
            className="mb-2 text-sm font-medium text-gray-900 sr-only dark:text-white"
          >
            Search
          </label>
          <div className="relative">
            <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
              <svg
                aria-hidden="true"
                className="w-5 h-5 text-gray-500 dark:text-gray-400"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  stroke-linecap="round"
                  stroke-linejoin="round"
                  stroke-width="2"
                  d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                ></path>
              </svg>
            </div>
            <input
              type="search"
              id="default-search"
              className="block w-full p-4 pl-10 text-sm text-gray-900 border border-gray-300 rounded-lg bg-gray-50 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
              placeholder="Country Name..."
              onChange={(e) => filterBySearch(e.target.value)}
              required
            />
          </div>
        </div>
        <div className="col-span-2 ">

        </div>
        <div className="md:col-span-2 m-auto w-9/12 col-span-6  justify-center flex lg:justify-end dark:bg-gray-800">
          <Menu as="div" className="relative inline-block text-left">
            <div className="">
              <Menu.Button className="inline-flex w-full justify-center rounded-md border border-gray-300 bg-white dark:bg-gray-800 dark:text-white px-4 py-2 text-sm font-medium text-gray-700 shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 focus:ring-offset-gray-100">
                Filter By Region
                <ChevronDownIcon
                  className="-mr-1 ml-2 h-5 w-5"
                  aria-hidden="true"
                />
              </Menu.Button>
            </div>

            <Transition
              as={Fragment}
              enter="transition ease-out duration-100"
              enterFrom="transform opacity-0 scale-95"
              enterTo="transform opacity-100 scale-100"
              leave="transition ease-in duration-75"
              leaveFrom="transform opacity-100 scale-100"
              leaveTo="transform opacity-0 scale-95"
            >
              <Menu.Items className="absolute right-0 z-10 mt-2 w-56 origin-top-right rounded-md bg-white shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none">
                <div className="py-1">
                  <Menu.Item>
                    {({ active }) => (
                      <a
                        href="#"
                        className={classNames(
                          active
                            ? "bg-gray-100 text-gray-900"
                            : "text-gray-700",
                          "block px-4 py-2 text-sm"
                        )}
                        onClick={(e) => HandleContinent("Africa")}                 
                      >
                        Africa
                      </a>
                    )}
                  </Menu.Item>
                  <Menu.Item>
                    {({ active }) => (
                      <a
                        href="#"
                        className={classNames(
                          active
                            ? "bg-gray-100 text-gray-900"
                            : "text-gray-700",
                          "block px-4 py-2 text-sm"
                        )}
                        onClick={(e) => HandleContinent("Americas")}                    
                      >
                        Americas
                      </a>
                    )}
                  </Menu.Item>
                  <Menu.Item>
                    {({ active }) => (
                      <a
                        href="#"
                        className={classNames(
                          active
                            ? "bg-gray-100 text-gray-900"
                            : "text-gray-700",
                          "block px-4 py-2 text-sm"
                        )}
                        onClick={(e) => HandleContinent("Asia")}                    

                      >
                        Asia
                      </a>
                    )}
                  </Menu.Item>
                  <Menu.Item>
                    {({ active }) => (
                      <a
                        href="#"
                        className={classNames(
                          active
                            ? "bg-gray-100 text-gray-900"
                            : "text-gray-700",
                          "block px-4 py-2 text-sm"
                        )}


                        onClick={(e) => HandleContinent("Europe")}                    
                      >
                        Europe
                      </a>
                    )}
                  </Menu.Item>
                  <Menu.Item>
                    {({ active }) => (
                      <a
                        href="#"
                        className={classNames(
                          active
                            ? "bg-gray-100 text-gray-900"
                            : "text-gray-700",
                          "block px-4 py-2 text-sm"
                        )}
                        onClick={(e) => HandleContinent("Oceina")}                      >
                        Oceina
                      </a>
                    )}
                  </Menu.Item>
                
                </div>
              </Menu.Items>
            </Transition>
          </Menu>
        </div>
      </div>

      <div className="grid grid-cols-12 gap-4 py-10">
        {filteredList.map((country) => (
          <div className="lg:col-span-3 md:col-span-6 col-span-12 py-4 px-4">
            <div className=" bg-white border border-gray-200 rounded-lg shadow dark:bg-gray-800 dark:border-gray-700">
              <a href="#">
                {/* <div className="h-48 rounded-t-lg w-auto"> */}
                <img className="rounded-t-lg w-auto" src={country.png} alt="" />

                {/* </div> */}
              </a>
              <div className="p-5">
                <a href="#">
                  <h5 className="mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">
                    {country.name}
                  </h5>
                </a>
                <p className="mb-3 font-normal text-gray-700 dark:text-gray-400">
                  Population: {country.population}
                </p>
                <p className="mb-3 font-normal text-gray-700 dark:text-gray-400">
                  Population: {country.region}
                </p>
                <p className="mb-3 font-normal text-gray-700 dark:text-gray-400">
                  Population: {country.capital}
                </p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </>
  );
}
