import React, { useState } from "react";
import { Transition } from "@headlessui/react";
import "./InnerCode.css";
import myLogo from "./assets/images/logo.svg";
import myNav from "./assets/images/icon-menu.svg";
import myNavClose from "./assets/images/icon-menu-close.svg";

function MyNavbar() {
  const [isOpen, setIsOpen] = useState(false);
  const [darkToggle, setDarkToggle] = React.useState(false);

  return (
    <div className = "MyNavBar">
      <nav className={`bg-white border-gray-200   rounded pb-4 ${
                      darkToggle && "dark"
                    }`}>
        <div className="max-w-7xl mx-auto dark:bg-gray-300">
          <div className="flex items-center justify-between h-16">
            <div className="flex-shrink-0">
              <div className="text-4xl font-bold">Where in the world?</div>
            </div>

            <div
              className="hidden w-full md:block md:w-auto"
              id="navbar-default"
            >
              <ul className="flex flex-col p-4 mt-4 border border-gray-100 rounded-lg bg-gray-50 md:flex-row md:space-x-8 md:mt-0 md:text-sm md:font-medium md:border-0 md:bg-white dark:bg-gray-800 md:dark:bg-gray-900 dark:border-gray-700">
                <div>
           
                 
                    <label className="toggleDarkBtn">
                      <input
                        type="checkbox"
                        onClick={() => setDarkToggle(!darkToggle)}
                      />
                      <span className="slideBtnTg round"></span>
                    </label>
                    <div className=" dark:bg-gray-900">
                    </div>
                  </div>
              
              </ul>
            </div>

        </div>
        </div>

      </nav>
    </div>
  );
}
export default MyNavbar;
